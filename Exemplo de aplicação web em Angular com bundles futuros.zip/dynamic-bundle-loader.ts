import { Injectable, Injector, NgModuleRef, Type } from '@angular/core';
import { Router } from '@angular/router';

export interface DynamicBundle {
  name: string;
  url: string;
  moduleName: string;
  routes: any[];
}

@Injectable({
  providedIn: 'root'
})
export class DynamicBundleLoaderService {
  private loadedBundles = new Map<string, any>();

  constructor(
    private router: Router,
    private injector: Injector
  ) { }

  /**
   * Carrega um bundle externo dinamicamente
   * @param bundle Configuração do bundle a ser carregado
   */
  async loadBundle(bundle: DynamicBundle): Promise<void> {
    try {
      // Verifica se o bundle já foi carregado
      if (this.loadedBundles.has(bundle.name)) {
        console.log(`Bundle ${bundle.name} já está carregado`);
        return;
      }

      // Simula o carregamento de um bundle externo
      // Em um cenário real, isso carregaria um arquivo JavaScript externo
      console.log(`Carregando bundle: ${bundle.name} de ${bundle.url}`);
      
      // Simula delay de carregamento
      await this.simulateAsyncLoad(bundle.url);
      
      // Registra o bundle como carregado
      this.loadedBundles.set(bundle.name, bundle);
      
      // Adiciona as rotas dinamicamente
      this.addDynamicRoutes(bundle.routes);
      
      console.log(`Bundle ${bundle.name} carregado com sucesso!`);
    } catch (error) {
      console.error(`Erro ao carregar bundle ${bundle.name}:`, error);
      throw error;
    }
  }

  /**
   * Simula o carregamento assíncrono de um bundle
   * @param url URL do bundle
   */
  private async simulateAsyncLoad(url: string): Promise<void> {
    return new Promise((resolve) => {
      // Simula um delay de carregamento de rede
      setTimeout(() => {
        console.log(`Bundle carregado de: ${url}`);
        resolve();
      }, 1000);
    });
  }

  /**
   * Adiciona rotas dinamicamente ao roteador
   * @param routes Rotas a serem adicionadas
   */
  private addDynamicRoutes(routes: any[]): void {
    const config = this.router.config;
    
    // Adiciona as novas rotas antes da rota wildcard (se existir)
    const wildcardIndex = config.findIndex(route => route.path === '**');
    
    if (wildcardIndex !== -1) {
      // Insere antes da rota wildcard
      config.splice(wildcardIndex, 0, ...routes);
    } else {
      // Adiciona no final se não houver rota wildcard
      config.push(...routes);
    }
    
    // Atualiza a configuração do roteador
    this.router.resetConfig(config);
  }

  /**
   * Lista todos os bundles carregados
   */
  getLoadedBundles(): string[] {
    return Array.from(this.loadedBundles.keys());
  }

  /**
   * Verifica se um bundle específico está carregado
   * @param bundleName Nome do bundle
   */
  isBundleLoaded(bundleName: string): boolean {
    return this.loadedBundles.has(bundleName);
  }

  /**
   * Remove um bundle carregado (para fins de demonstração)
   * @param bundleName Nome do bundle a ser removido
   */
  unloadBundle(bundleName: string): void {
    if (this.loadedBundles.has(bundleName)) {
      this.loadedBundles.delete(bundleName);
      console.log(`Bundle ${bundleName} foi removido`);
      
      // Em um cenário real, você também removeria as rotas associadas
      // e limparia os recursos do módulo
    }
  }
}