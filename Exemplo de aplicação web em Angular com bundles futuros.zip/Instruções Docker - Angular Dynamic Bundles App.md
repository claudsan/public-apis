# Instruções Docker - Angular Dynamic Bundles App

Este documento fornece as instruções para construir e executar a aplicação Angular de exemplo em um container Docker.

## Pré-requisitos

- Docker instalado e em execução em sua máquina.

## Conteúdo do Pacote

Você deve ter os seguintes arquivos no mesmo diretório:

- `Dockerfile`
- `nginx.conf`
- O código fonte da aplicação Angular (a pasta `angular-dynamic-bundles-app` que você já possui).

## Como Usar

### 1. Navegue até o diretório da aplicação

Certifique-se de que você está no diretório raiz da aplicação Angular (`angular-dynamic-bundles-app`), onde o `Dockerfile` e o `nginx.conf` estão localizados.

```bash
cd /caminho/para/sua/pasta/angular-dynamic-bundles-app
```

### 2. Construa a Imagem Docker

Execute o seguinte comando para construir a imagem Docker. Este processo pode levar alguns minutos, pois ele irá instalar as dependências do Node.js e construir a aplicação Angular dentro do container.

```bash
docker build -t angular-dynamic-bundles-app .
```

- `docker build`: Comando para construir uma imagem Docker.
- `-t angular-dynamic-bundles-app`: Atribui a tag `angular-dynamic-bundles-app` à imagem. Você pode usar outro nome se preferir.
- `.`: Indica que o Dockerfile está no diretório atual.

### 3. Execute o Container Docker

Após a imagem ser construída com sucesso, você pode executar o container:

```bash
docker run -d -p 8080:80 --name angular-app-container angular-dynamic-bundles-app
```

- `docker run`: Comando para executar um container Docker.
- `-d`: Executa o container em modo 

detached` (em segundo plano).
- `-p 8080:80`: Mapeia a porta 8080 da sua máquina local para a porta 80 do container. Você pode alterar a porta local (8080) se desejar.
- `--name angular-app-container`: Atribui um nome ao container para facilitar o gerenciamento. Você pode usar outro nome.
- `angular-dynamic-bundles-app`: O nome da imagem Docker que você construiu na etapa anterior.

### 4. Acesse a Aplicação

Abra seu navegador e acesse:

```
http://localhost:8080
```

Você deverá ver a aplicação Angular em execução.

### 5. Gerenciando o Container (Opcional)

- **Parar o container:**
  ```bash
  docker stop angular-app-container
  ```

- **Iniciar o container:**
  ```bash
  docker start angular-app-container
  ```

- **Remover o container (após parar):**
  ```bash
  docker rm angular-app-container
  ```

- **Remover a imagem Docker (após remover o container):**
  ```bash
  docker rmi angular-dynamic-bundles-app
  ```

## Estrutura dos Arquivos

- **`Dockerfile`**: Define as etapas para construir a imagem Docker da aplicação.
- **`nginx.conf`**: Configuração do servidor web Nginx para servir a aplicação Angular.

## Notas Importantes

- O `Dockerfile` utiliza um processo de build em duas etapas (multi-stage build) para otimizar o tamanho final da imagem.
- O Nginx é usado para servir os arquivos estáticos da aplicação Angular, garantindo um ambiente de produção leve e eficiente.
- Certifique-se de que a porta 8080 (ou a porta que você escolher) não esteja em uso em sua máquina local antes de executar o container.

---

**Com estas instruções, você poderá facilmente conteinerizar e executar sua aplicação Angular!** 🚀

