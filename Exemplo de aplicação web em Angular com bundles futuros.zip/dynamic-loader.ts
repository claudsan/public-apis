import { Component } from '@angular/core';
import { DynamicBundleLoaderService, DynamicBundle } from '../../services/dynamic-bundle-loader';

@Component({
  selector: 'app-dynamic-loader',
  standalone: false,
  templateUrl: './dynamic-loader.html',
  styleUrls: ['./dynamic-loader.css']
})
export class DynamicLoaderComponent {
  loadedBundles: string[] = [];
  isLoading = false;
  
  // Bundles de exemplo para demonstração
  availableBundles: DynamicBundle[] = [
    {
      name: 'analytics-bundle',
      url: 'https://cdn.example.com/bundles/analytics.js',
      moduleName: 'AnalyticsModule',
      routes: [
        {
          path: 'analytics',
          component: null, // Em um cenário real, seria o componente carregado
          data: { title: 'Analytics', dynamicallyLoaded: true }
        }
      ]
    },
    {
      name: 'reports-bundle',
      url: 'https://cdn.example.com/bundles/reports.js',
      moduleName: 'ReportsModule',
      routes: [
        {
          path: 'reports',
          component: null, // Em um cenário real, seria o componente carregado
          data: { title: 'Reports', dynamicallyLoaded: true }
        }
      ]
    },
    {
      name: 'settings-bundle',
      url: 'https://cdn.example.com/bundles/settings.js',
      moduleName: 'SettingsModule',
      routes: [
        {
          path: 'settings',
          component: null, // Em um cenário real, seria o componente carregado
          data: { title: 'Settings', dynamicallyLoaded: true }
        }
      ]
    }
  ];

  constructor(private bundleLoader: DynamicBundleLoaderService) {
    this.updateLoadedBundles();
  }

  async loadBundle(bundle: DynamicBundle): Promise<void> {
    if (this.bundleLoader.isBundleLoaded(bundle.name)) {
      alert(`Bundle ${bundle.name} já está carregado!`);
      return;
    }

    this.isLoading = true;
    try {
      await this.bundleLoader.loadBundle(bundle);
      this.updateLoadedBundles();
      alert(`Bundle ${bundle.name} carregado com sucesso!`);
    } catch (error) {
      alert(`Erro ao carregar bundle ${bundle.name}: ${error}`);
    } finally {
      this.isLoading = false;
    }
  }

  unloadBundle(bundleName: string): void {
    this.bundleLoader.unloadBundle(bundleName);
    this.updateLoadedBundles();
    alert(`Bundle ${bundleName} foi removido!`);
  }

  private updateLoadedBundles(): void {
    this.loadedBundles = this.bundleLoader.getLoadedBundles();
  }

  isBundleLoaded(bundleName: string): boolean {
    return this.bundleLoader.isBundleLoaded(bundleName);
  }
}
