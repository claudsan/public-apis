import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DynamicLoaderComponent } from './components/dynamic-loader/dynamic-loader';

const routes: Routes = [
  { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
  { 
    path: 'dashboard', 
    loadChildren: () => import('./features/dashboard/dashboard-module').then(m => m.DashboardModule) 
  },
  { 
    path: 'products', 
    loadChildren: () => import('./features/products/products-module').then(m => m.ProductsModule) 
  },
  { 
    path: 'users', 
    loadChildren: () => import('./features/users/users-module').then(m => m.UsersModule) 
  },
  { 
    path: 'dynamic-loader', 
    component: DynamicLoaderComponent 
  },
  { path: '**', redirectTo: '/dashboard' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
